from django.apps import AppConfig


class ActionsConfig(AppConfig):
    name = 'actions'
